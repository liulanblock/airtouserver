import { DefaultConfig } from './config.default';

export default () => {
  const config: DefaultConfig = {};
  return config;
};
